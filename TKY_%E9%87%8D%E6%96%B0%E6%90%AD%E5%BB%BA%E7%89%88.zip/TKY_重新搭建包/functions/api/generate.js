function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }
  });
}

export async function onRequestPost({ request, env }) {
  if (!env.DEEPSEEK_API_KEY) {
    return json({ error: "AI 服务还未配置。请先在 Cloudflare Pages 中添加 DEEPSEEK_API_KEY 密钥。" }, 503);
  }

  const length = Number(request.headers.get("content-length") || 0);
  if (length > 300_000) return json({ error: "请求内容过大，请缩短后重试。" }, 413);

  let body;
  try { body = await request.json(); }
  catch { return json({ error: "请求格式错误，请重试。" }, 400); }

  if (!Array.isArray(body.messages) || body.messages.length < 1 || body.messages.length > 8) {
    return json({ error: "消息格式不正确。" }, 400);
  }
  let total = 0;
  for (const m of body.messages) {
    if (!m || !["system", "user", "assistant"].includes(m.role) || typeof m.content !== "string" || m.content.length > 100_000) {
      return json({ error: "消息内容不符合要求。" }, 400);
    }
    total += m.content.length;
  }
  if (total > 250_000) return json({ error: "请求内容过长，请分段创作。" }, 413);

  const requested = env.DEEPSEEK_MODEL || "deepseek-chat";
  const allowed = new Set(["deepseek-chat", "deepseek-reasoner"]);
  if (!allowed.has(requested)) return json({ error: "当前配置的 DeepSeek 模型名称不受支持。" }, 500);
  const maxTokens = Math.min(24_000, Math.max(256, Number(body.max_tokens) || 6_000));

  let upstream;
  try {
    upstream = await fetch("https://api.deepseek.com/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${env.DEEPSEEK_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: requested,
        messages: body.messages,
        max_tokens: maxTokens,
        temperature: 0.7,
        stream: false
      })
    });
  } catch {
    return json({ error: "暂时无法连接 DeepSeek，请稍后重试。" }, 502);
  }

  let data = {};
  try { data = await upstream.json(); } catch {}
  if (!upstream.ok) {
    const status = upstream.status === 429 ? 429 : 502;
    const message = upstream.status === 401
      ? "DeepSeek API 密钥无效，请检查 Cloudflare 中的 DEEPSEEK_API_KEY。"
      : upstream.status === 402
        ? "DeepSeek 账户余额不足，请前往 DeepSeek 开放平台检查余额。"
        : upstream.status === 429
          ? "AI 请求过于频繁或额度受限，请稍后再试。"
          : "AI 生成暂时失败，请检查 DeepSeek 账户、模型权限后重试。";
    return json({ error: message }, status);
  }
  return json(data);
}
