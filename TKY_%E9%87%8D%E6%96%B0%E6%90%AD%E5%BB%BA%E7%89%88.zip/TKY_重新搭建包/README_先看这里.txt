TKY AI 创作平台｜重新搭建版

目录：
- index.html：完整前端网站
- assets/：首页及推荐内容图片
- functions/api/generate.js：Cloudflare Pages 后端接口

部署到 Cloudflare Pages：
1. 将本压缩包上传到 GitHub 仓库根目录。
2. Cloudflare Pages 连接此 GitHub 仓库，Production branch 选择 main。
3. Build command 可留空；Build output directory 填 /（如果平台不接受 /，填 .）。
4. 在 Pages 项目 Settings → Variables and Secrets → Production 添加加密密钥：
   名称：DEEPSEEK_API_KEY
   值：DeepSeek 开放平台创建的 API Key 原文（不要加 Bearer、引号或空格）。
5. 保存后重新部署。

网站使用浏览器本地存储保存作品和主题设置；不同设备之间不会自动同步。
AI 功能需要配置有效的 DeepSeek API Key 后才能使用。
切勿把 API Key 写入 index.html、GitHub 文件或发送给任何人。
