export async function onRequestPost({ request, env }) {
  if (!env.DEEPSEEK_API_KEY) return json({error:"AI 服务还未配置，请先在 Cloudflare Pages 添加 DEEPSEEK_API_KEY。"},503);
  let body; try { body=await request.json(); } catch { return json({error:"请求格式错误。"},400); }
  if (!Array.isArray(body.messages) || body.messages.length<1 || body.messages.length>8) return json({error:"请求内容格式错误。"},400);
  const total=body.messages.reduce((n,m)=>n+String(m?.content||"").length,0);
  if (total>250000) return json({error:"请求内容过长。"},413);
  const max_tokens=Math.min(24000,Math.max(256,Number(body.max_tokens)||6000));
  const model=env.DEEPSEEK_MODEL||"deepseek-flash";
  if (!["deepseek-flash","deepseek-v4-pro"].includes(model)) return json({error:"模型配置不支持。"},400);
  const upstream=await fetch("https://api.deepseek.com/chat/completions",{method:"POST",headers:{"Authorization":`Bearer ${env.DEEPSEEK_API_KEY}`,"Content-Type":"application/json"},body:JSON.stringify({model,messages:body.messages,max_tokens,thinking:{type:"disabled"},temperature:0.7,stream:false})});
  const data=await upstream.json().catch(()=>({}));
  if(!upstream.ok){const status=upstream.status===429?429:502;const message=upstream.status===401?"DeepSeek API 密钥无效，请检查 Cloudflare 中的 DEEPSEEK_API_KEY。":upstream.status===402?"DeepSeek 账户余额不足，请检查账户余额。":upstream.status===429?"AI 请求过于频繁或额度受限，请稍后再试。":"AI 生成暂时失败，请检查 DeepSeek 账户和模型权限后重试。";return json({error:message},status);}
  return json(data);
}
function json(data,status=200){return new Response(JSON.stringify(data),{status,headers:{"Content-Type":"application/json; charset=utf-8"}});}
