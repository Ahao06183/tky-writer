TKY 网站部署包

压缩包根目录包含 index.html 和 functions/api/generate.js。
Cloudflare Pages 构建命令：unzip -o TKY_重新搭建版.zip -d .
构建输出目录：/

AI 接口需要在 Cloudflare Pages 项目设置中添加 DEEPSEEK_API_KEY（密钥），部署后才可生成 AI 文案。
作品目前保存在当前浏览器设备中；账号和云端同步尚未接入。
